from django.contrib import admin
from .models import Marks


admin.site.register(Marks)